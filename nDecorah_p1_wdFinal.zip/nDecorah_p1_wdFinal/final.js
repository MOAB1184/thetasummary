var pizzaCount = 0;
const pizzaClicker = document.getElementById("pizzaClicker");
function pizzaClick() {
    pizzaCount += 50000;
    document.getElementById("pizzaCount").innerHTML = pizzaCount;
}
function onPepperoniClick() {
    if (pizzaCount > 49) {
        pizzaCount -= 50;
        document.getElementById("pizzaCount").innerHTML = pizzaCount;
    }
}
document.getElementById("pepperoniCost").addEventListener("click", onPepperoniClick);
document.getElementById("pizzaClicker").addEventListener("click", pizzaClick);